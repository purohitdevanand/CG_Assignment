﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CG_Assessment_AzureBlobStorage.Model
{
    public class Email
    {
        public string EmailId { get; set; }
        public string  EmailBody { get; set; }
    }
}

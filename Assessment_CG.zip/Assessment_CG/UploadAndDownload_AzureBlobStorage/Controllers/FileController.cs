﻿using Azure.Storage;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using CG_Assessment_AzureBlobStorage.Model;

namespace CG_Assessment_AzureBlobStorage.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public FileController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost(nameof(UploadFile))]
        public async Task<IActionResult> UploadFile(IFormFile files)
        {
            string systemFileName = files.FileName;
            string blobstorageconnection = _configuration.GetValue<string>("BlobConnectionString");
            // Retrieve storage account from connection string.
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(blobstorageconnection);
            // Create the blob client.
            CloudBlobClient blobClient = cloudStorageAccount.CreateCloudBlobClient();
            // Retrieve a reference to a container.
            CloudBlobContainer container = blobClient.GetContainerReference(_configuration.GetValue<string>("BlobContainerName"));
            // This also does not make a service call; it only creates a local object.
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(systemFileName);
            await using (var data = files.OpenReadStream())
            {
                await blockBlob.UploadFromStreamAsync(data);
            }
            return Ok("File Uploaded Successfully");
        }
        [HttpPost(nameof(DownloadFile))]
        public async Task<IActionResult> DownloadFile(string fileName)
        {

            CloudBlockBlob blockBlob;
            await using (MemoryStream memoryStream = new MemoryStream())
            {
                string blobstorageconnection = _configuration.GetValue<string>("BlobConnectionString");
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(blobstorageconnection);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(_configuration.GetValue<string>("BlobContainerName"));
                blockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                await blockBlob.DownloadToStreamAsync(memoryStream);
            }

            Stream blobStream = blockBlob.OpenReadAsync().Result;
            return File(blobStream, blockBlob.Properties.ContentType, blockBlob.Name);

        }

        [HttpPost(nameof(ShareFileWithSASToken))]
        public async Task<IActionResult> ShareFileWithSASToken(string fileName, string emailID)
        {
            var blobContainerName = _configuration.GetValue<string>("BlobContainerName");
            Azure.Storage.Sas.BlobSasBuilder blobSasBuilder = new Azure.Storage.Sas.BlobSasBuilder()
            {
                BlobContainerName = blobContainerName,
                BlobName = fileName,
                ExpiresOn = DateTime.UtcNow.AddMinutes(60),//Let SAS token expire after 60 minutes.
            };
            blobSasBuilder.SetPermissions(Azure.Storage.Sas.BlobSasPermissions.Read);//User will only be able to read the blob and it's properties
            var storageKey = _configuration.GetValue<string>("StorageKey");
            var sasToken = blobSasBuilder.ToSasQueryParameters(new StorageSharedKeyCredential(blobContainerName, storageKey)).ToString();
            string url = $"https://teststoragedemodev.blob.core.windows.net/{blobContainerName}/{fileName}";
            BlobClient clinet = new BlobClient(new Uri(url));

            var sasUrl = clinet.Uri.AbsoluteUri + "?" + sasToken;

            Email objEmail = new Email();
            objEmail.EmailId = emailID;
            objEmail.EmailBody = sasUrl;

            await SendEmailAsync(objEmail);

            return Ok("File url sent with SAS token");
        }

        [HttpPost(nameof(SendEmailAsync))]
        public async Task<IActionResult> SendEmailAsync([FromBody] Email email)
        {
            IQueueClient queueClient = new QueueClient(_configuration["QueueConnectionString"], _configuration["QueueName"]);
            var emailJSON = JsonConvert.SerializeObject(email);
            var emailMessage = new Message(Encoding.UTF8.GetBytes(emailJSON))
            {
                MessageId = Guid.NewGuid().ToString(),
                ContentType = "application/json"
            };
            await queueClient.SendAsync(emailMessage).ConfigureAwait(false);

            return Ok("Email has been successfully pushed to queue");
        }
    }
}
